<div class="space-y-6">

    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <div class="bg-white rounded-3xl shadow border p-6">

        <div class="flex justify-between items-start mb-5">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">
                    Order #<?php echo e($order->id); ?>

                </h2>

                <p class="text-gray-500 mt-2">
                    Nama Pemesan:
                    <span class="font-bold text-gray-900">
                        <?php echo e($order->customer_name); ?>

                    </span>
                </p>
                <p class="text-gray-500">
                    Tanggal:
                    <span class="font-bold text-gray-900">
                        <?php echo e($order->created_at->format('d M Y - H:i')); ?>

                    </span>
                </p>

                <p class="text-gray-500">
                    Pembayaran: <?php echo e($order->payment_method); ?>

                </p>

                <p class="text-gray-500">
                    Status:
                    <span class="font-bold <?php echo e($order->status == 'Selesai' ? 'text-green-600' : 'text-orange-500'); ?>">
                        <?php echo e($order->status); ?>

                    </span>
                </p>
            </div>

            <div class="text-right">
                <p class="text-gray-500">Total</p>
                <h3 class="text-3xl font-extrabold text-blue-600">
                    Rp <?php echo e(number_format($order->total,0,',','.')); ?>

                </h3>
            </div>
        </div>

        <div class="border-t pt-4 space-y-3">
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex justify-between text-gray-700">
                    <span>
                        <?php echo e($item->product_name); ?> x <?php echo e($item->quantity); ?>

                    </span>
                    <span class="font-bold">
                        Rp <?php echo e(number_format($item->subtotal,0,',','.')); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($order->status != 'Selesai'): ?>

<div class="grid grid-cols-1 md:grid-cols-3 gap-3 mt-6">

    <form action="/kasir/orders/<?php echo e($order->id); ?>/status" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="status" value="Sedang Dibuat">

        <button class="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-2xl font-bold">
            Sedang Dibuat
        </button>
    </form>

    <form action="/kasir/orders/<?php echo e($order->id); ?>/status" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="status" value="Siap Diambil">

        <button class="w-full bg-blue-500 hover:bg-blue-600 text-white py-4 rounded-2xl font-bold">
            Siap Diambil
        </button>
    </form>

    <form action="/kasir/orders/<?php echo e($order->id); ?>/status" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="status" value="Selesai">

        <button class="w-full bg-green-500 hover:bg-green-600 text-white py-4 rounded-2xl font-bold">
            Selesai
        </button>
    </form>

</div>

<?php endif; ?>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <div class="bg-white rounded-3xl shadow p-10 text-center">
        <h2 class="text-2xl font-bold text-gray-700">
            Belum ada order masuk
        </h2>
    </div>

    <?php endif; ?>

</div><?php /**PATH C:\laragon\www\coffee-shop\resources\views/kasir/partials/order-list.blade.php ENDPATH**/ ?>